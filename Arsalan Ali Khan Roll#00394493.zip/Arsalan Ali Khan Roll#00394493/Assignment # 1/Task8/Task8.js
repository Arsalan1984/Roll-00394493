
var USdollars = 10;
var PkRs = 155; 
var SaudiRiyals = 25;
var PakistaniRs = 41;
var multiply = USdollars * PkRs;
var multiplication = SaudiRiyals * PakistaniRs;
var sumof = multiply + multiplication;

console.log(multiply);
console.log(multiplication);


document.write(`Total Currency in Pakistani Rs.  ${multiply} and ${multiplication} is ${sumof}`);