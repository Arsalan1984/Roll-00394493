var a = 10;
document.write("The value of a is " + a);
document.write("<br>");
document.write("<br>");
a++
document.write("The value of a is " + a);
document.write("<br>");
document.write ("Now the value of ++a is " + a);
document.write("<br>");
document.write("<br>");
document.write("The value of a is " + a);
document.write("<br>");
a++
document.write ("Now the value of ++a is " + a);
document.write("<br>");
document.write("<br>");
a--
document.write("The value of a is " + a);
document.write("<br>");
document.write ("Now the value of --a is " + a);
document.write("<br>");
document.write("<br>");
document.write("The value of a-- is " + a);
document.write("<br>");
a--
document.write ("Now the value of --a is " + a);
document.write("<br>");
document.write("<br>");