var birthyear = 1990;

document.write("My birth year is" + birthyear); + "<br>"
document.write("Data Type of my declared variable is number");