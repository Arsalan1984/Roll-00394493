var a = 3;
var b = 5;
var c = a + b;
var d = a - b;
var e = a / b;
var f = a % b;
var g = a ** b;


console.log(c);
console.log(d);
console.log(e);
console.log(f);
console.log(g);
