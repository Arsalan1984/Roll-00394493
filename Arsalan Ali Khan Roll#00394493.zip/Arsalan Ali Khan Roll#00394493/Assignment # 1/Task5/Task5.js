var a = 3;
var b = 5;
var c = a + b;

document.write(`The sum of ${a} and ${b} is ${c}`);