var Email = "onlineclass@gmail.com"
alert("hello world");
alert("john Deo");
alert("15 years old");
alert("CertifiedMobile Application Development");
alert("My Email Address is " + Email);