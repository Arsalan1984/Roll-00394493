var a = '';
var b = 5;
var c = 6;
var e = 3;

console.log(b);
++b
console.log(b);
console.log(c);
++c
console.log(c);

var d = b + c;

console.log(d);
--d
console.log(d)
console.log(e/d);