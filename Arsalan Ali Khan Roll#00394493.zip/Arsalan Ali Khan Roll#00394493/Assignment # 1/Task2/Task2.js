alert("write a script to display this in browser through JS");
var age = 25;
alert("i am " + age + "years old");